export interface Visualization {
  id: string
  title: string
  timestamp: number
  widgetsConfig: string // JSON string of widget configurations
  dataSourceId: string // Reference to the data source
  dataType: string
  modelUsed: string
  language?: string // Language of the insights
  truncated?: boolean
}


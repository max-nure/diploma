export interface DataSource {
  id: string
  name: string
  data: any // The parsed JSON data
  originalFormat: "json" | "csv"
  timestamp: number
  filePath?: string // Path to the stored file
}


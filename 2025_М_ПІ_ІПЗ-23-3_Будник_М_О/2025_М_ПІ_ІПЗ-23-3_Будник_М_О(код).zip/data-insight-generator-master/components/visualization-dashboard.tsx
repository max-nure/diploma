"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { NewVisualizationDialog } from "@/components/new-visualization-dialog"
import { VisualizationContent } from "@/components/visualization-content"
import { fetchVisualizationById, fetchDataSourceById } from "@/app/actions"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"
import { Loader2 } from "lucide-react"

// Import the LoadingOverlay component
import { LoadingOverlay } from "./loading-overlay"

interface VisualizationDashboardProps {
  initialVisualizations: Visualization[]
}

export default function VisualizationDashboard({ initialVisualizations }: VisualizationDashboardProps) {
  const [visualizations, setVisualizations] = useState<Visualization[]>(initialVisualizations)
  const [selectedVisualization, setSelectedVisualization] = useState<string | null>(
      initialVisualizations.length > 0 ? initialVisualizations[0].id : null,
  )
  const [currentVisualization, setCurrentVisualization] = useState<Visualization | null>(null)
  const [currentDataSource, setCurrentDataSource] = useState<DataSource | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingData, setIsLoadingData] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Load the selected visualization and its data source
  useEffect(() => {
    async function loadVisualizationData() {
      if (!selectedVisualization) {
        setCurrentVisualization(null)
        setCurrentDataSource(null)
        return
      }

      setIsLoadingData(true)
      setError(null)

      try {
        // Fetch the visualization
        const visualization = await fetchVisualizationById(selectedVisualization)
        setCurrentVisualization(visualization)

        if (visualization) {
          // Fetch the data source
          const dataSource = await fetchDataSourceById(visualization.dataSourceId)
          setCurrentDataSource(dataSource)
        } else {
          setCurrentDataSource(null)
        }
      } catch (err) {
        console.error("Error loading visualization data:", err)
        setError("Failed to load visualization data")
      } finally {
        setIsLoadingData(false)
      }
    }

    loadVisualizationData()
  }, [selectedVisualization])

  const handleCreateVisualization = async (formData: FormData) => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const result = await response.json()

      // Add the new visualization to the list
      if (result.visualization) {
        setVisualizations((prev) => [result.visualization, ...prev])
        setSelectedVisualization(result.visualization.id)
        setCurrentVisualization(result.visualization)
        setCurrentDataSource(result.dataSource)
      }

      setIsDialogOpen(false)
    } catch (err) {
      console.error("Error creating visualization:", err)
      setError(err instanceof Error ? err.message : "An unknown error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  // Add the LoadingOverlay component at the top level of the return statement
  return (
      <>
        <LoadingOverlay
            isVisible={isLoading}
            message="Our AI is analyzing your data and generating insightful visualizations. This may take a minute depending on the size and complexity of your data."
        />

        <Header
            onNewVisualization={() => setIsDialogOpen(true)}
            visualizations={visualizations}
            selectedVisualization={selectedVisualization}
            onSelectVisualization={setSelectedVisualization}
        />

        <main className="mt-8">
          {isLoadingData ? (
              <div className="flex flex-col items-center justify-center min-h-[200px]">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="mt-2">Loading visualization data...</p>
              </div>
          ) : error ? (
              <div className="p-6 bg-destructive/10 rounded-lg border border-destructive">
                <h3 className="text-xl font-semibold text-destructive mb-2">Error</h3>
                <p>{error}</p>
              </div>
          ) : selectedVisualization ? (
              <VisualizationContent
                  visualization={currentVisualization}
                  dataSource={currentDataSource}
                  isLoading={isLoadingData} // Add this line
              />
          ) : (
              <div className="text-center p-12 border-2 border-dashed rounded-lg">
                <h3 className="text-xl font-medium mb-2">No visualization selected</h3>
                <p className="text-muted-foreground mb-4">
                  Create a new visualization or select an existing one from the dropdown.
                </p>
                <button
                    onClick={() => setIsDialogOpen(true)}
                    className="bg-primary text-primary-foreground px-4 py-2 rounded-md"
                >
                  Create New Visualization
                </button>
              </div>
          )}
        </main>

        <NewVisualizationDialog
            isOpen={isDialogOpen}
            onClose={() => setIsDialogOpen(false)}
            onSubmit={handleCreateVisualization}
            isLoading={isLoading}
        />
      </>
  )
}


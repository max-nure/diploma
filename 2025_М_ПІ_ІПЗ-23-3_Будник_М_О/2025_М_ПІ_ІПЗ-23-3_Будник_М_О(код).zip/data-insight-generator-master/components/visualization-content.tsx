"use client"

import { useState } from "react"
import { WidgetRenderer } from "./widget-renderer"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

interface VisualizationContentProps {
  visualization: Visualization | null
  dataSource: DataSource | null
}

export function VisualizationContent({ visualization, dataSource }: VisualizationContentProps) {
  const [error, setError] = useState<string | null>(null)

  if (!visualization) {
    return (
      <div className="p-6 bg-amber-50 rounded-lg border border-amber-200">
        <h3 className="text-xl font-semibold text-amber-700 mb-2">Visualization Not Found</h3>
        <p>The selected visualization could not be found.</p>
      </div>
    )
  }

  if (!dataSource) {
    return (
      <div className="p-6 bg-amber-50 rounded-lg border border-amber-200">
        <h3 className="text-xl font-semibold text-amber-700 mb-2">Data Source Not Found</h3>
        <p>The data source for this visualization could not be found.</p>
        <p className="mt-2">Visualization ID: {visualization.id}</p>
        <p>Data Source ID: {visualization.dataSourceId}</p>
      </div>
    )
  }

  return <WidgetRenderer visualization={visualization} dataSource={dataSource} />
}


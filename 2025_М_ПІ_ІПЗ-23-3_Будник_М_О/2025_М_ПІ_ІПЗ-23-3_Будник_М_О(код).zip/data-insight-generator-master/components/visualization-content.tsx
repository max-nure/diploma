"use client"

import { useState } from "react"
import { WidgetRenderer } from "./widget-renderer"
import { ErrorBoundary } from "./error-boundary"
import { VisualizationSkeleton } from "./visualization-skeleton"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

interface VisualizationContentProps {
    visualization: Visualization | null
    dataSource: DataSource | null
    isLoading?: boolean
}

export function VisualizationContent({ visualization, dataSource, isLoading = false }: VisualizationContentProps) {
    const [error, setError] = useState<string | null>(null)

    if (isLoading) {
        return <VisualizationSkeleton />
    }

    if (!visualization) {
        return (
            <Alert variant="warning" className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-4 w-4 text-amber-700" />
                <AlertTitle className="text-amber-700">Visualization Not Found</AlertTitle>
                <AlertDescription className="text-amber-700">The selected visualization could not be found.</AlertDescription>
            </Alert>
        )
    }

    if (!dataSource) {
        return (
            <Alert variant="warning" className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-4 w-4 text-amber-700" />
                <AlertTitle className="text-amber-700">Data Source Not Found</AlertTitle>
                <AlertDescription className="text-amber-700">
                    <p>The data source for this visualization could not be found.</p>
                    <p className="mt-2">Visualization ID: {visualization.id}</p>
                    <p>Data Source ID: {visualization.dataSourceId}</p>
                </AlertDescription>
            </Alert>
        )
    }

    return (
        <ErrorBoundary
            fallback={
                <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Rendering Error</AlertTitle>
                    <AlertDescription>
                        <p>
                            There was an error rendering this visualization. This could be due to invalid data or widget
                            configuration.
                        </p>
                        <p className="mt-2">Try creating a new visualization or contact support if the issue persists.</p>
                    </AlertDescription>
                </Alert>
            }
        >
            <div className="visualization-container space-y-6">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <h2 className="text-2xl font-bold">{visualization.title}</h2>
                        {visualization.language && (
                            <Badge variant="outline" className="capitalize">
                                {visualization.language}
                            </Badge>
                        )}
                    </div>
                    <p className="text-muted-foreground">
                        Generated on {new Date(visualization.timestamp).toLocaleString()} with {visualization.modelUsed}
                    </p>
                    {visualization.truncated && (
                        <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-700 text-sm">
                            <strong>Note:</strong> Your data was truncated due to size limitations. This analysis is based on a subset
                            of the data.
                        </div>
                    )}
                </div>

                <WidgetRenderer visualization={visualization} dataSource={dataSource} />
            </div>
        </ErrorBoundary>
    )
}


"use client"

import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { NewVisualization } from "@/components/new-visualization"

export function Header() {
    return (
        <header className="flex flex-col sm:flex-row justify-between items-center gap-4 pb-6 border-b">
            <h1 className="text-3xl font-bold">Data Insight Generator</h1>

            <div className="flex items-center gap-2">
                <NewVisualization
                    trigger={
                        <Button>
                            <PlusCircle className="h-4 w-4 mr-2" />
                            New Visualization
                        </Button>
                    }
                />
            </div>
        </header>
    )
}


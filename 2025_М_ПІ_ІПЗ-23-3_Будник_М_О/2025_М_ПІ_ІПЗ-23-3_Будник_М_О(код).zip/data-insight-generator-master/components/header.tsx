"use client"

import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle } from "lucide-react"
import type { Visualization } from "@/types/visualization"

interface HeaderProps {
  onNewVisualization: () => void
  visualizations: Visualization[]
  selectedVisualization: string | null
  onSelectVisualization: (id: string) => void
}

export function Header({
  onNewVisualization,
  visualizations,
  selectedVisualization,
  onSelectVisualization,
}: HeaderProps) {
  return (
    <header className="flex flex-col sm:flex-row justify-between items-center gap-4 pb-6 border-b">
      <h1 className="text-3xl font-bold">Data Insight Generator</h1>

      <div className="flex items-center gap-2">
        <Select value={selectedVisualization || ""} onValueChange={onSelectVisualization}>
          <SelectTrigger className="w-[220px]">
            <SelectValue placeholder="Select visualization" />
          </SelectTrigger>
          <SelectContent>
            {visualizations.map((vis) => (
              <SelectItem key={vis.id} value={vis.id}>
                {vis.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button onClick={onNewVisualization}>
          <PlusCircle className="h-4 w-4 mr-2" />
          New
        </Button>
      </div>
    </header>
  )
}


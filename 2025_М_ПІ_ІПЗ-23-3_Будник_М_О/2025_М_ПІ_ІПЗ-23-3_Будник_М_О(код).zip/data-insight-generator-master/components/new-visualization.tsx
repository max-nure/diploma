"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { NewVisualizationDialog } from "@/components/new-visualization-dialog"
import { LoadingOverlay } from "@/components/loading-overlay"

interface NewVisualizationProps {
  trigger: React.ReactNode
}

export function NewVisualization({ trigger }: NewVisualizationProps) {
  const router = useRouter()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleCreateVisualization = async (formData: FormData) => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const result = await response.json()

      // Redirect to the new visualization
      if (result.visualization) {
        router.push(`/visualization/${result.visualization.id}`)
      }

      setIsDialogOpen(false)
    } catch (err) {
      console.error("Error creating visualization:", err)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <div onClick={() => setIsDialogOpen(true)}>{trigger}</div>

      <LoadingOverlay
        isVisible={isLoading}
        message="Our AI is analyzing your data and generating insightful visualizations. This may take a minute depending on the size and complexity of your data."
      />

      <NewVisualizationDialog
        isOpen={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        onSubmit={handleCreateVisualization}
        isLoading={isLoading}
      />
    </>
  )
}


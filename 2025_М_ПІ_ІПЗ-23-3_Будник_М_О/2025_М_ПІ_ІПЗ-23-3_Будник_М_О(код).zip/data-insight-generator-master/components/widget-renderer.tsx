"use client"

import { useState, useEffect } from "react"
import { Chart } from "./visualization/chart"
import { DataTable } from "./visualization/data-table"
import { InsightsCard } from "./visualization/insights-card"
import { MetricsCard } from "./visualization/metrics-card"
import { DataViewer } from "./data-viewer"
import { Card } from "@/components/ui/card"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

interface WidgetRendererProps {
  visualization: Visualization
  dataSource: DataSource
}

export function WidgetRenderer({ visualization, dataSource }: WidgetRendererProps) {
  const [error, setError] = useState<string | null>(null)
  const [widgets, setWidgets] = useState<any[]>([])

  console.log('visualization',visualization)

  useEffect(() => {
    try {
      // Parse the widgets configuration
      const widgetConfigs = visualization.widgetsConfig

      // Process each widget and apply data transformations if needed
      const processedWidgets = widgetConfigs.map((widget: any, index: number) => {
        try {
          if (widget.dataTransform) {
            try {
              // Create a function from the dataTransform string
              const transformFn = new Function("data", widget.dataTransform)

              // Apply the transformation to the data source
              widget.data = transformFn(dataSource.data)
            } catch (transformError) {
              console.error(`Error in data transformation for widget ${index}:`, transformError)
              // If transformation fails, keep the original data or set to empty array
              widget.data = widget.data || []
            }
          } else {
            widget.data = widget.data || []
          }
          return widget
        } catch (widgetError) {
          console.error(`Error processing widget ${index}:`, widgetError)
          return widget
        }
      })

      setWidgets(processedWidgets)
      setError(null)
    } catch (err) {
      console.error("Error processing widgets:", err)
      setError(err instanceof Error ? err.message : "An unknown error occurred")
      setWidgets([])
    }
  }, [visualization, dataSource])

  if (error) {
    return (
      <div className="p-6 bg-destructive/10 rounded-lg border border-destructive">
        <h3 className="text-xl font-semibold text-destructive mb-2">Rendering Error</h3>
        <p>{error}</p>
        <pre className="mt-4 p-4 bg-muted rounded overflow-auto text-sm">{visualization.widgetsConfig}</pre>
      </div>
    )
  }

  if (widgets.length === 0) {
    return (
      <div className="p-6 bg-muted rounded-lg border">
        <h3 className="text-xl font-semibold mb-2">No Widgets</h3>
        <p>No visualization widgets were found. This could be due to an error in processing the data.</p>
      </div>
    )
  }

  return (
    <div className="visualization-container space-y-6">
      <div>
        <h2 className="text-2xl font-bold">{visualization.title}</h2>
        <p className="text-muted-foreground">Generated on {new Date(visualization.timestamp).toLocaleString()}</p>
        {visualization.truncated && (
          <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-700 text-sm">
            <strong>Note:</strong> Your data was truncated due to size limitations. This analysis is based on a subset
            of the data.
          </div>
        )}
      </div>

      <DataViewer data={dataSource.data} title={`Data Source: ${dataSource.name}`} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {widgets.map((widget, index) => {
          switch (widget.type) {
            case "chart":
              return (
                <Chart
                  key={index}
                  type={widget.chartType}
                  title={widget.title}
                  description={widget.description}
                  data={widget.data}
                  dataKeys={widget.dataKeys}
                  xAxisKey={widget.xAxisKey}
                  colors={widget.colors}
                  height={widget.height}
                  insights={widget.insights}
                />
              )
            case "table":
              return (
                <DataTable
                  key={index}
                  title={widget.title}
                  description={widget.description}
                  data={widget.data}
                  columns={widget.columns}
                  caption={widget.caption}
                  insights={widget.insights}
                />
              )
            case "insights":
              return (
                <InsightsCard
                  key={index}
                  title={widget.title}
                  description={widget.description}
                  insights={widget.insights}
                  type={widget.insightType}
                />
              )
            case "metrics":
              return (
                <MetricsCard
                  key={index}
                  title={widget.title}
                  description={widget.description}
                  metrics={widget.metrics}
                />
              )
            case "summary":
              return (
                <Card key={index} className="col-span-1 md:col-span-2">
                  <div className="p-6">
                    <h2 className="text-xl font-bold mb-4">{widget.title}</h2>
                    <p>{widget.content}</p>
                  </div>
                </Card>
              )
            default:
              return null
          }
        })}
      </div>
    </div>
  )
}


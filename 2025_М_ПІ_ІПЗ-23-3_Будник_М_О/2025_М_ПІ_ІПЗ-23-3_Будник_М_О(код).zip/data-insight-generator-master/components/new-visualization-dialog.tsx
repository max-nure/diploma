"use client"

import type React from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Upload, AlertCircle, Loader2 } from "lucide-react"
import { useState } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface NewVisualizationDialogProps {
  isOpen: boolean
  onClose: () => void
  onSubmit: (formData: FormData) => void
  isLoading?: boolean
}

export function NewVisualizationDialog({ isOpen, onClose, onSubmit, isLoading = false }: NewVisualizationDialogProps) {
  const [fileError, setFileError] = useState<string | null>(null)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setFileError(null)

    const formData = new FormData(e.currentTarget)
    const file = formData.get("file") as File

    // Validate file
    if (!file || file.size === 0) {
      setFileError("Please select a file")
      return
    }

    const fileName = file.name.toLowerCase()
    if (!fileName.endsWith(".json") && !fileName.endsWith(".csv")) {
      setFileError("Only JSON and CSV files are supported")
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      setFileError("File too large. Please upload a file smaller than 10MB.")
      return
    }

    onSubmit(formData)
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFileError(null)

    const file = e.target.files?.[0]
    if (!file) return

    const fileName = file.name.toLowerCase()
    if (!fileName.endsWith(".json") && !fileName.endsWith(".csv")) {
      setFileError("Only JSON and CSV files are supported")
      return
    }

    if (file.size > 10 * 1024 * 1024) {
      setFileError("File too large. Please upload a file smaller than 10MB.")
    }
  }

  return (
      <Dialog open={isOpen} onOpenChange={(open) => !isLoading && onClose()}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create New Visualization</DialogTitle>
          </DialogHeader>

          <form onSubmit={handleSubmit}>
            <div className="space-y-6 py-4">
              <div className="space-y-2">
                <Label htmlFor="file">Upload Data File</Label>
                <div className="border-2 border-dashed rounded-md p-6 flex flex-col items-center justify-center">
                  <Upload className="h-10 w-10 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground mb-2">Drag and drop or click to upload</p>
                  <Input
                      id="file"
                      name="file"
                      type="file"
                      className="max-w-sm"
                      accept=".json,.csv"
                      required
                      onChange={handleFileChange}
                  />
                  <p className="mt-2 text-xs text-muted-foreground">
                    Supported formats: JSON, CSV. Maximum file size: 10MB.
                  </p>
                </div>

                {fileError && (
                    <Alert variant="destructive" className="mt-2">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription>{fileError}</AlertDescription>
                    </Alert>
                )}
              </div>

              <div className="space-y-2">
                <Label>Select AI Model</Label>
                <RadioGroup defaultValue="gpt" name="model">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="gpt" id="gpt" />
                      <Label htmlFor="gpt">GPT-4o</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="claude" id="claude" />
                      <Label htmlFor="claude">Claude 3</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="gemini" id="gemini" />
                      <Label htmlFor="gemini">Gemini Pro 1.5</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="deepseek" id="deepseek" />
                      <Label htmlFor="deepseek">Deepseek R1</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>Insights Language</Label>
                <RadioGroup defaultValue="english" name="language">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="english" id="english" />
                      <Label htmlFor="english">English</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="ukrainian" id="ukrainian" />
                      <Label htmlFor="ukrainian">Ukrainian</Label>
                    </div>
                  </div>
                </RadioGroup>
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Generating...
                    </>
                ) : (
                    "Generate Insights"
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
  )
}


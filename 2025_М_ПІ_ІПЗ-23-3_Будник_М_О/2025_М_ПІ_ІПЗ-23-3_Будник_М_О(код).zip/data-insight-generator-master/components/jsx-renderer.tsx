"use client"

import { useEffect, useState } from "react"
import { Card } from "@/components/ui/card"
import type { Visualization } from "@/types/visualization"
import * as React from "react"
import * as Recharts from "recharts"
import { cn } from "@/lib/utils"

// Import all shadcn components that might be used in visualizations
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface JsxRendererProps {
  visualization: Visualization | undefined
}

export function JsxRenderer({ visualization }: JsxRendererProps) {
  const [error, setError] = useState<string | null>(null)
  const [renderedContent, setRenderedContent] = useState<React.ReactNode | null>(null)

  useEffect(() => {
    if (!visualization) {
      setRenderedContent(null)
      return
    }

    try {
      // Create a scope with all the components that might be used in the JSX
      const scope = {
        React,
        ...Recharts,
        Button,
        Table,
        TableBody,
        TableCaption,
        TableCell,
        TableHead,
        TableHeader,
        TableRow,
        Card,
        ChartContainer,
        ChartTooltip,
        ChartTooltipContent,
        cn,
      }

      // Create a function that will evaluate the JSX with the given scope
      const createElementFromJSX = new Function(
        ...Object.keys(scope),
        `try { return ${visualization.jsxCode} } catch (err) { console.error(err); return React.createElement('div', null, 'Error rendering JSX: ' + err.message) }`,
      )

      // Call the function with the scope values
      const element = createElementFromJSX(...Object.values(scope))
      setRenderedContent(element)
      setError(null)
    } catch (err) {
      console.error("Error rendering JSX:", err)
      setError(err instanceof Error ? err.message : "An unknown error occurred")
      setRenderedContent(null)
    }
  }, [visualization])

  if (error) {
    return (
      <div className="p-6 bg-destructive/10 rounded-lg border border-destructive">
        <h3 className="text-xl font-semibold text-destructive mb-2">Rendering Error</h3>
        <p>{error}</p>
        <pre className="mt-4 p-4 bg-muted rounded overflow-auto text-sm">{visualization?.jsxCode}</pre>
      </div>
    )
  }

  if (!visualization) {
    return null
  }

  return (
    <div className="visualization-container">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">{visualization.title}</h2>
        <p className="text-muted-foreground">Generated on {new Date(visualization.timestamp).toLocaleString()}</p>
        {visualization.truncated && (
          <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-700 text-sm">
            <strong>Note:</strong> Your data was truncated due to size limitations. This analysis is based on a subset
            of the data.
          </div>
        )}
      </div>

      <div className="jsx-content">{renderedContent}</div>
    </div>
  )
}


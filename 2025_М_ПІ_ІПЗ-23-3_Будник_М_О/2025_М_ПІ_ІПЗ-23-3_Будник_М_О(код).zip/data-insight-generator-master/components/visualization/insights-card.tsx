import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export interface InsightsCardProps {
  title: string
  description?: string
  insights: string[] | string
  type?: "list" | "text"
}

export function InsightsCard({ title, description, insights, type = "list" }: InsightsCardProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <p className="text-muted-foreground">{description}</p>}
      </CardHeader>
      <CardContent>
        {type === "list" && Array.isArray(insights) ? (
          <ul className="list-disc pl-5 space-y-2">
            {insights.map((insight, index) => (
              <li key={index}>{insight}</li>
            ))}
          </ul>
        ) : (
          <p>{typeof insights === "string" ? insights : insights.join(" ")}</p>
        )}
      </CardContent>
    </Card>
  )
}


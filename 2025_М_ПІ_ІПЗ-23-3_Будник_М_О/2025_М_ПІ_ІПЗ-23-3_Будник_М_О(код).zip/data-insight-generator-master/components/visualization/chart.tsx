"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export interface ChartProps {
  type: "bar" | "line" | "pie" | "area" | "scatter"
  title: string
  description?: string
  data: any[]
  dataKeys: string[]
  xAxisKey?: string
  colors?: string[]
  height?: number
  insights?: string
}

const CHART_COLORS = [
  "#4e79a7",
  "#f28e2c",
  "#e15759",
  "#76b7b2",
  "#59a14f",
  "#edc949",
  "#af7aa1",
  "#ff9da7",
]

export function Chart({
                        type,
                        title,
                        description,
                        data,
                        dataKeys,
                        xAxisKey = "name",
                        colors = CHART_COLORS,
                        height = 300,
                        insights,
                      }: ChartProps) {
  // Create config object for ChartContainer
  const config = dataKeys.reduce(
      (acc, key, index) => {
        acc[key] = {
          label: key.charAt(0).toUpperCase() + key.slice(1),
          color: colors[index % colors.length],
        }
        return acc
      },
      {} as Record<string, { label: string; color: string }>,
  )

  return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>{title}</CardTitle>
          {description && <p className="text-muted-foreground">{description}</p>}
        </CardHeader>
        <CardContent>
          <ChartContainer config={config} className={`h-[${height}px]`}>
            <ResponsiveContainer width="100%" height={height}>
              {type === "bar" && (
                  <BarChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={xAxisKey} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    {dataKeys.map((key, index) => (
                        <Bar key={key} dataKey={key} fill={colors[index % colors.length]} />
                    ))}
                  </BarChart>
              )}

              {type === "line" && (
                  <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={xAxisKey} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    {dataKeys.map((key, index) => (
                        <Line
                            key={key}
                            type="monotone"
                            dataKey={key}
                            stroke={colors[index % colors.length]}
                            strokeWidth={2}
                        />
                    ))}
                  </LineChart>
              )}

              {type === "pie" && (
                  <PieChart>
                    <Pie
                        data={data}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={height / 3}
                        fill="#8884d8"
                        dataKey={dataKeys[0]}
                    >
                      {data.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
              )}

              {type === "area" && (
                  <AreaChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={xAxisKey} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    {dataKeys.map((key, index) => (
                        <Area
                            key={key}
                            type="monotone"
                            dataKey={key}
                            stroke={colors[index % colors.length]}
                            fill={colors[index % colors.length]}
                            fillOpacity={0.3}
                        />
                    ))}
                  </AreaChart>
              )}

              {type === "scatter" && (
                  <ScatterChart>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey={xAxisKey} />
                    <YAxis />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    {dataKeys.map((key, index) => (
                        <Scatter key={key} name={key} data={data} fill={colors[index % colors.length]} />
                    ))}
                  </ScatterChart>
              )}
            </ResponsiveContainer>
          </ChartContainer>

          {insights && (
              <div className="mt-4 text-sm text-muted-foreground">
                <h4 className="font-medium text-foreground mb-1">Insights:</h4>
                <p>{insights}</p>
              </div>
          )}
        </CardContent>
      </Card>
  )
}

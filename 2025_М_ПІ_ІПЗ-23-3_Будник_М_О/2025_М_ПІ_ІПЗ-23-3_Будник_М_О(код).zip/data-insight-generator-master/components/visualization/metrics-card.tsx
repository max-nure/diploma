import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export interface MetricsCardProps {
  title: string
  description?: string
  metrics: {
    label: string
    value: string | number
    change?: {
      value: number
      positive: boolean
    }
  }[]
}

export function MetricsCard({ title, description, metrics }: MetricsCardProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <p className="text-muted-foreground">{description}</p>}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {metrics.map((metric, index) => (
            <div key={index} className="flex flex-col">
              <p className="text-sm font-medium text-muted-foreground">{metric.label}</p>
              <div className="flex items-baseline">
                <p className="text-2xl font-bold">{metric.value}</p>
                {metric.change && (
                  <span className={`ml-2 text-sm ${metric.change.positive ? "text-green-600" : "text-red-600"}`}>
                    {metric.change.positive ? "↑" : "↓"} {Math.abs(metric.change.value)}%
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}


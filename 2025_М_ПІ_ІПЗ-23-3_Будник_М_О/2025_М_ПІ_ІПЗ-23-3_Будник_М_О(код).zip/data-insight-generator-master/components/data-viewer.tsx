"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight, Download, Eye, EyeOff } from "lucide-react"

interface DataViewerProps {
  data: any
  title?: string
}

export function DataViewer({ data, title = "Data Source" }: DataViewerProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleNode = (path: string) => {
    const newExpandedNodes = new Set(expandedNodes)
    if (newExpandedNodes.has(path)) {
      newExpandedNodes.delete(path)
    } else {
      newExpandedNodes.add(path)
    }
    setExpandedNodes(newExpandedNodes)
  }

  const downloadData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${title.toLowerCase().replace(/\s+/g, "-")}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Recursive function to render JSON tree
  const renderJsonTree = (obj: any, path = "root", depth = 0) => {
    if (obj === null) return <span className="text-gray-500">null</span>
    if (obj === undefined) return <span className="text-gray-500">undefined</span>

    if (typeof obj !== "object") {
      if (typeof obj === "string") return <span className="text-green-600">"{obj}"</span>
      if (typeof obj === "number") return <span className="text-blue-600">{obj}</span>
      if (typeof obj === "boolean") return <span className="text-purple-600">{obj.toString()}</span>
      return <span>{String(obj)}</span>
    }

    const isArray = Array.isArray(obj)
    const isEmpty = Object.keys(obj).length === 0

    if (isEmpty) {
      return <span>{isArray ? "[]" : "{}"}</span>
    }

    const isExpanded = expandedNodes.has(path)

    if (depth > 0 && !isExpanded) {
      return (
        <div className="flex items-center">
          <button onClick={() => toggleNode(path)} className="mr-1 p-1 hover:bg-gray-100 rounded">
            <ChevronRight className="h-3 w-3" />
          </button>
          <span>
            {isArray ? `Array(${Object.keys(obj).length})` : `Object {${Object.keys(obj).length} properties}`}
          </span>
        </div>
      )
    }

    return (
      <div className="ml-2">
        {depth > 0 && (
          <button onClick={() => toggleNode(path)} className="mr-1 p-1 hover:bg-gray-100 rounded">
            <ChevronDown className="h-3 w-3" />
          </button>
        )}
        <span>{isArray ? "[" : "{"}</span>
        <div className="ml-4">
          {Object.entries(obj).map(([key, value], index) => (
            <div key={`${path}-${key}`} className="flex">
              <span className="text-red-600 mr-1">
                {isArray ? index : `"${key}"`}
                {isArray ? "" : ":"}{" "}
              </span>
              {renderJsonTree(value, `${path}-${key}`, depth + 1)}
              {index < Object.keys(obj).length - 1 && ","}
            </div>
          ))}
        </div>
        <div>{isArray ? "]" : "}"}</div>
      </div>
    )
  }

  // Function to render data as a table (for array of objects)
  const renderTable = () => {
    if (!Array.isArray(data) || data.length === 0) {
      return <p className="text-muted-foreground">No tabular data available</p>
    }

    // Get all unique keys from all objects
    const allKeys = new Set<string>()
    data.forEach((item) => {
      if (typeof item === "object" && item !== null) {
        Object.keys(item).forEach((key) => allKeys.add(key))
      }
    })

    const keys = Array.from(allKeys)

    if (keys.length === 0) {
      return <p className="text-muted-foreground">No properties found in data</p>
    }

    return (
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-muted">
              {keys.map((key) => (
                <th key={key} className="p-2 text-left border">
                  {key}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.slice(0, 100).map((item: any, index: number) => (
              <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-muted/30"}>
                {keys.map((key) => (
                  <td key={`${index}-${key}`} className="p-2 border">
                    {item[key] !== undefined && item[key] !== null && typeof item[key] !== "object"
                      ? String(item[key])
                      : typeof item[key] === "object"
                        ? JSON.stringify(item[key]).substring(0, 50) +
                          (JSON.stringify(item[key]).length > 50 ? "..." : "")
                        : ""}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
        {data.length > 100 && <p className="mt-2 text-sm text-muted-foreground">Showing 100 of {data.length} rows</p>}
      </div>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setIsExpanded(!isExpanded)}>
            {isExpanded ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
            {isExpanded ? "Hide Data" : "View Data"}
          </Button>
          <Button variant="outline" size="sm" onClick={downloadData}>
            <Download className="h-4 w-4 mr-1" />
            Download
          </Button>
        </div>
      </CardHeader>
      {isExpanded && (
        <CardContent>
          <Tabs defaultValue="json">
            <TabsList className="mb-4">
              <TabsTrigger value="json">JSON View</TabsTrigger>
              <TabsTrigger value="table">Table View</TabsTrigger>
            </TabsList>
            <TabsContent value="json" className="overflow-auto max-h-[500px] p-4 bg-muted/30 rounded-md">
              <pre className="text-sm font-mono">{renderJsonTree(data)}</pre>
            </TabsContent>
            <TabsContent value="table" className="overflow-auto max-h-[500px]">
              {renderTable()}
            </TabsContent>
          </Tabs>
        </CardContent>
      )}
    </Card>
  )
}


"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { ChevronDown, ChevronRight, Download, Eye, EyeOff } from "lucide-react"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface DataViewerProps {
  data: any
  title?: string
}

export function DataViewer({ data, title = "Data Source" }: DataViewerProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [jsonViewDepth, setJsonViewDepth] = useState(2)
  const [searchTerm, setSearchTerm] = useState("")

  const toggleNode = (path: string) => {
    const newExpandedNodes = new Set(expandedNodes)
    if (newExpandedNodes.has(path)) {
      newExpandedNodes.delete(path)
    } else {
      newExpandedNodes.add(path)
    }
    setExpandedNodes(newExpandedNodes)
  }

  const downloadData = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${title.toLowerCase().replace(/\s+/g, "-")}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  // Get all unique keys from all objects for table view
  const allKeys = useMemo(() => {
    if (!Array.isArray(data) || data.length === 0) return []

    const keySet = new Set<string>()
    // Only process the first 100 items to avoid performance issues
    const sampleData = data.slice(0, 100)

    sampleData.forEach((item) => {
      if (typeof item === "object" && item !== null) {
        Object.keys(item).forEach((key) => keySet.add(key))
      }
    })

    return Array.from(keySet)
  }, [data])

  // Filter data based on search term
  const filteredData = useMemo(() => {
    if (!searchTerm || !Array.isArray(data)) return data

    return data.filter((item) => {
      if (typeof item !== "object" || item === null) {
        return String(item).toLowerCase().includes(searchTerm.toLowerCase())
      }

      // Search in all string/number values
      return Object.values(item).some((value) => {
        if (typeof value === "string" || typeof value === "number") {
          return String(value).toLowerCase().includes(searchTerm.toLowerCase())
        }
        return false
      })
    })
  }, [data, searchTerm])

  // Calculate pagination
  const paginatedData = useMemo(() => {
    if (!Array.isArray(filteredData)) return []

    const startIndex = (currentPage - 1) * pageSize
    return filteredData.slice(startIndex, startIndex + pageSize)
  }, [filteredData, currentPage, pageSize])

  const totalPages = useMemo(() => {
    if (!Array.isArray(filteredData)) return 1
    return Math.max(1, Math.ceil(filteredData.length / pageSize))
  }, [filteredData, pageSize])

  // Reset to page 1 when search term changes
  useEffect(() => {
    setCurrentPage(1)
  }, [searchTerm])

  // Recursive function to render JSON tree with depth control
  const renderJsonTree = (obj: any, path = "root", depth = 0) => {
    if (obj === null) return <span className="text-gray-500">null</span>
    if (obj === undefined) return <span className="text-gray-500">undefined</span>

    if (typeof obj !== "object") {
      if (typeof obj === "string") return <span className="text-green-600">"{obj}"</span>
      if (typeof obj === "number") return <span className="text-blue-600">{obj}</span>
      if (typeof obj === "boolean") return <span className="text-purple-600">{obj.toString()}</span>
      return <span>{String(obj)}</span>
    }

    const isArray = Array.isArray(obj)
    const isEmpty = Object.keys(obj).length === 0

    if (isEmpty) {
      return <span>{isArray ? "[]" : "{}"}</span>
    }

    // If we've reached the max depth and not expanded, show collapsed view
    if (depth >= jsonViewDepth && !expandedNodes.has(path)) {
      return (
          <div className="flex items-center">
            <button onClick={() => toggleNode(path)} className="mr-1 p-1 hover:bg-gray-100 rounded">
              <ChevronRight className="h-3 w-3" />
            </button>
            <span>
            {isArray ? `Array(${Object.keys(obj).length})` : `Object {${Object.keys(obj).length} properties}`}
          </span>
          </div>
      )
    }

    // If the node is expanded or we're within the depth limit
    return (
        <div className="ml-2">
          {depth > 0 && (
              <button onClick={() => toggleNode(path)} className="mr-1 p-1 hover:bg-gray-100 rounded">
                <ChevronDown className="h-3 w-3" />
              </button>
          )}
          <span>{isArray ? "[" : "{"}</span>
          <div className="ml-4">
            {/* Limit the number of items shown for large arrays/objects */}
            {Object.entries(obj)
                .slice(0, 100)
                .map(([key, value], index) => (
                    <div key={`${path}-${key}`} className="flex">
                <span className="text-red-600 mr-1">
                  {isArray ? index : `"${key}"`}
                  {isArray ? "" : ":"}{" "}
                </span>
                      {renderJsonTree(value, `${path}-${key}`, depth + 1)}
                      {index < Math.min(Object.keys(obj).length - 1, 99) && ","}
                    </div>
                ))}
            {Object.keys(obj).length > 100 && (
                <div className="text-gray-500 italic">... {Object.keys(obj).length - 100} more items</div>
            )}
          </div>
          <div>{isArray ? "]" : "}"}</div>
        </div>
    )
  }

  // Function to render data as a table with pagination
  const renderTable = () => {
    if (!Array.isArray(filteredData) || filteredData.length === 0) {
      return <p className="text-muted-foreground">No tabular data available</p>
    }

    if (allKeys.length === 0) {
      return <p className="text-muted-foreground">No properties found in data</p>
    }

    return (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
            <div className="w-full sm:w-64">
              <Label htmlFor="search" className="mb-1 block">
                Search
              </Label>
              <Input
                  id="search"
                  placeholder="Search data..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
              />
            </div>

            <div className="flex items-center gap-2">
              <Label htmlFor="pageSize" className="whitespace-nowrap">
                Rows per page:
              </Label>
              <select
                  id="pageSize"
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                  className="p-2 border rounded"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
              <tr className="bg-muted">
                {allKeys.map((key) => (
                    <th key={key} className="p-2 text-left border">
                      {key}
                    </th>
                ))}
              </tr>
              </thead>
              <tbody>
              {paginatedData.map((item: any, index: number) => (
                  <tr key={index} className={index % 2 === 0 ? "bg-white" : "bg-muted/30"}>
                    {allKeys.map((key) => (
                        <td key={`${index}-${key}`} className="p-2 border">
                          {item[key] !== undefined && item[key] !== null && typeof item[key] !== "object"
                              ? String(item[key])
                              : typeof item[key] === "object"
                                  ? JSON.stringify(item[key]).substring(0, 50) +
                                  (JSON.stringify(item[key]).length > 50 ? "..." : "")
                                  : ""}
                        </td>
                    ))}
                  </tr>
              ))}
              </tbody>
            </table>
          </div>

          {Array.isArray(filteredData) && filteredData.length > pageSize && (
              <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
                <div className="text-sm text-muted-foreground">
                  Showing {Math.min(filteredData.length, (currentPage - 1) * pageSize + 1)} to{" "}
                  {Math.min(filteredData.length, currentPage * pageSize)} of {filteredData.length} entries
                  {searchTerm && ` (filtered from ${data.length} total entries)`}
                </div>

                <Pagination>
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious
                          onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                          disabled={currentPage === 1}
                      />
                    </PaginationItem>

                    {/* First page */}
                    {currentPage > 3 && (
                        <PaginationItem>
                          <PaginationLink onClick={() => setCurrentPage(1)}>1</PaginationLink>
                        </PaginationItem>
                    )}

                    {/* Ellipsis if needed */}
                    {currentPage > 4 && (
                        <PaginationItem>
                          <PaginationEllipsis />
                        </PaginationItem>
                    )}

                    {/* Page before current */}
                    {currentPage > 1 && (
                        <PaginationItem>
                          <PaginationLink onClick={() => setCurrentPage(currentPage - 1)}>{currentPage - 1}</PaginationLink>
                        </PaginationItem>
                    )}

                    {/* Current page */}
                    <PaginationItem>
                      <PaginationLink isActive>{currentPage}</PaginationLink>
                    </PaginationItem>

                    {/* Page after current */}
                    {currentPage < totalPages && (
                        <PaginationItem>
                          <PaginationLink onClick={() => setCurrentPage(currentPage + 1)}>{currentPage + 1}</PaginationLink>
                        </PaginationItem>
                    )}

                    {/* Ellipsis if needed */}
                    {currentPage < totalPages - 3 && (
                        <PaginationItem>
                          <PaginationEllipsis />
                        </PaginationItem>
                    )}

                    {/* Last page */}
                    {currentPage < totalPages - 2 && (
                        <PaginationItem>
                          <PaginationLink onClick={() => setCurrentPage(totalPages)}>{totalPages}</PaginationLink>
                        </PaginationItem>
                    )}

                    <PaginationItem>
                      <PaginationNext
                          onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                          disabled={currentPage === totalPages}
                      />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              </div>
          )}
        </div>
    )
  }

  // Function to render JSON view with depth control
  const renderJsonView = () => {
    return (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <Label htmlFor="jsonDepth">Expand depth:</Label>
              <select
                  id="jsonDepth"
                  value={jsonViewDepth}
                  onChange={(e) => setJsonViewDepth(Number(e.target.value))}
                  className="p-2 border rounded"
              >
                <option value={1}>1 level</option>
                <option value={2}>2 levels</option>
                <option value={3}>3 levels</option>
                <option value={4}>4 levels</option>
                <option value={5}>5 levels</option>
              </select>
            </div>

            <Button variant="outline" size="sm" onClick={() => setExpandedNodes(new Set())}>
              Collapse All
            </Button>
          </div>

          <div className="overflow-auto max-h-[500px] p-4 bg-muted/30 rounded-md">
            <pre className="text-sm font-mono">{renderJsonTree(data)}</pre>
          </div>
        </div>
    )
  }

  return (
      <Card className="w-full">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>{title}</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setIsExpanded(!isExpanded)}>
              {isExpanded ? <EyeOff className="h-4 w-4 mr-1" /> : <Eye className="h-4 w-4 mr-1" />}
              {isExpanded ? "Hide Data" : "View Data"}
            </Button>
            <Button variant="outline" size="sm" onClick={downloadData}>
              <Download className="h-4 w-4 mr-1" />
              Download
            </Button>
          </div>
        </CardHeader>
        {isExpanded && (
            <CardContent>
              <Tabs defaultValue="table">
                <TabsList className="mb-4">
                  <TabsTrigger value="table">Table View</TabsTrigger>
                  <TabsTrigger value="json">JSON View</TabsTrigger>
                </TabsList>
                <TabsContent value="table">{renderTable()}</TabsContent>
                <TabsContent value="json">{renderJsonView()}</TabsContent>
              </Tabs>
            </CardContent>
        )}
      </Card>
  )
}


import Link from "next/link"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, BarChart2, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Visualization } from "@/types/visualization"

interface VisualizationCardProps {
  visualization: Visualization
}

export function VisualizationCard({ visualization }: VisualizationCardProps) {
  const date = new Date(visualization.timestamp)
  const formattedDate = date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })

  return (
      <Card className="h-full flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <CardTitle className="line-clamp-2">{visualization.title}</CardTitle>
            <Badge variant="outline" className="ml-2 shrink-0">
              {visualization.dataType.toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="flex-grow">
          <div className="flex items-center text-sm text-muted-foreground mb-2">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{formattedDate}</span>
          </div>
          <div className="flex items-center text-sm text-muted-foreground mb-2">
            <BarChart2 className="h-4 w-4 mr-1" />
            <span>Model: {visualization.modelUsed}</span>
          </div>
          {visualization.language && (
              <div className="flex items-center text-sm text-muted-foreground">
                <Globe className="h-4 w-4 mr-1" />
                <span className="capitalize">Language: {visualization.language}</span>
              </div>
          )}
        </CardContent>
        <CardFooter>
          <Link href={`/visualization/${visualization.id}`} className="w-full">
            <Button variant="outline" className="w-full">
              View Visualization
            </Button>
          </Link>
        </CardFooter>
      </Card>
  )
}


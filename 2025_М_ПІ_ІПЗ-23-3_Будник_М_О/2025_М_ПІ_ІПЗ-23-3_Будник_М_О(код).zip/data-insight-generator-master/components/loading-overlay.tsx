import { Loader2 } from "lucide-react"

interface LoadingOverlayProps {
    isVisible: boolean
    message?: string
}

export function LoadingOverlay({ isVisible, message = "Processing..." }: LoadingOverlayProps) {
    if (!isVisible) return null

    return (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
        <div className="bg-card p-6 rounded-lg shadow-lg flex flex-col items-center max-w-md">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <h3 className="text-xl font-medium mb-2">Processing Your Request</h3>
    <p className="text-muted-foreground text-center">{message}</p>
        </div>
        </div>
)
}


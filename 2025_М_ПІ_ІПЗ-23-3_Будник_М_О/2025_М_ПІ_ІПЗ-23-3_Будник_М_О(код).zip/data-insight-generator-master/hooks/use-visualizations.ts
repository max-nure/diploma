"use client"

import { useState, useEffect } from "react"
import type { Visualization } from "@/types/visualization"
import { saveToLocalStorage, loadFromLocalStorage } from "@/lib/storage"

// Update the hook to use the helper functions
export function useVisualizations() {
  const [visualizations, setVisualizations] = useState<Visualization[]>([])
  const [selectedVisualization, setSelectedVisualization] = useState<string | null>(null)

  // Load visualizations from localStorage on initial render
  useEffect(() => {
    const saved = loadFromLocalStorage<Visualization[]>("visualizations", [])
    setVisualizations(saved)

    // Select the most recent visualization if available
    if (saved.length > 0) {
      setSelectedVisualization(saved[0].id)
    }
  }, [])

  // Save visualizations to localStorage whenever they change
  useEffect(() => {
    if (visualizations.length > 0) {
      saveToLocalStorage("visualizations", visualizations)
    }
  }, [visualizations])

  const addVisualization = (visualization: Visualization) => {
    console.log("Adding visualization:", visualization)
    setVisualizations((prev) => {
      // Check if visualization already exists
      const exists = prev.some((v) => v.id === visualization.id)
      if (exists) {
        console.log(`Visualization ${visualization.id} already exists, updating it`)
        return prev.map((v) => (v.id === visualization.id ? visualization : v))
      }
      return [visualization, ...prev]
    })
  }

  const deleteVisualization = (id: string) => {
    setVisualizations((prev) => prev.filter((v) => v.id !== id))
    if (selectedVisualization === id) {
      setSelectedVisualization(visualizations[0]?.id || null)
    }
  }

  return {
    visualizations,
    selectedVisualization,
    setSelectedVisualization,
    addVisualization,
    deleteVisualization,
  }
}


"use client"

import { useState, useEffect } from "react"
import type { DataSource } from "@/types/data-source"
import { saveToLocalStorage, loadFromLocalStorage } from "@/lib/storage"

// Update the hook to use the helper functions
export function useDataSources() {
  const [dataSources, setDataSources] = useState<DataSource[]>([])

  // Load data sources from localStorage on initial render
  useEffect(() => {
    const saved = loadFromLocalStorage<DataSource[]>("dataSources", [])
    setDataSources(saved)
  }, [])

  // Save data sources to localStorage whenever they change
  useEffect(() => {
    if (dataSources.length > 0) {
      saveToLocalStorage("dataSources", dataSources)
    }
  }, [dataSources])

  const addDataSource = (dataSource: DataSource) => {
    console.log("Adding data source:", dataSource)
    setDataSources((prev) => {
      // Check if data source already exists
      const exists = prev.some((ds) => ds.id === dataSource.id)
      if (exists) {
        console.log(`Data source ${dataSource.id} already exists, updating it`)
        return prev.map((ds) => (ds.id === dataSource.id ? dataSource : ds))
      }
      return [dataSource, ...prev]
    })
  }

  const getDataSourceById = (id: string) => {
    const dataSource = dataSources.find((ds) => ds.id === id)
    if (!dataSource) {
      console.warn(`Data source ${id} not found`)
    }
    return dataSource || null
  }

  const deleteDataSource = (id: string) => {
    setDataSources((prev) => prev.filter((ds) => ds.id !== id))
  }

  return {
    dataSources,
    addDataSource,
    getDataSourceById,
    deleteDataSource,
  }
}


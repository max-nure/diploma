import fs from "fs"
import path from "path"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

// Define base paths for data storage
const DATA_DIR = path.join(process.cwd(), "data")
const VISUALIZATIONS_DIR = path.join(DATA_DIR, "visualizations")
const DATASOURCES_DIR = path.join(DATA_DIR, "datasources")

// Ensure directories exist
export function ensureDirectories() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true })
  }

  if (!fs.existsSync(VISUALIZATIONS_DIR)) {
    fs.mkdirSync(VISUALIZATIONS_DIR, { recursive: true })
  }

  if (!fs.existsSync(DATASOURCES_DIR)) {
    fs.mkdirSync(DATASOURCES_DIR, { recursive: true })
  }
}

// Create a safe filename from a title
export function createSafeFilename(title: string): string {
  return title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
}

// Save a visualization to the file system
export function saveVisualization(visualization: Visualization): string {
  ensureDirectories()

  const safeTitle = createSafeFilename(visualization.title)
  const filename = `${visualization.id}-${safeTitle}.json`
  const filePath = path.join(VISUALIZATIONS_DIR, filename)

  fs.writeFileSync(filePath, JSON.stringify(visualization, null, 2))
  return filename
}

// Save a data source to the file system
export function saveDataSource(dataSource: DataSource): string {
  ensureDirectories()

  const safeName = createSafeFilename(dataSource.name)
  const filename = `${dataSource.id}-${safeName}.json`
  const filePath = path.join(DATASOURCES_DIR, filename)

  fs.writeFileSync(filePath, JSON.stringify(dataSource, null, 2))
  return filename
}

// Get all visualizations
export function getAllVisualizations(): Visualization[] {
  ensureDirectories()

  try {
    const files = fs.readdirSync(VISUALIZATIONS_DIR)

    return files
      .filter((file) => file.endsWith(".json"))
      .map((file) => {
        const filePath = path.join(VISUALIZATIONS_DIR, file)
        const fileContent = fs.readFileSync(filePath, "utf-8")
        return JSON.parse(fileContent) as Visualization
      })
      .sort((a, b) => b.timestamp - a.timestamp) // Sort by timestamp, newest first
  } catch (error) {
    console.error("Error reading visualizations:", error)
    return []
  }
}

// Get a visualization by ID
export function getVisualizationById(id: string): Visualization | null {
  ensureDirectories()

  try {
    const files = fs.readdirSync(VISUALIZATIONS_DIR)
    const matchingFile = files.find((file) => file.startsWith(`${id}-`))

    if (!matchingFile) {
      return null
    }

    const filePath = path.join(VISUALIZATIONS_DIR, matchingFile)
    const fileContent = fs.readFileSync(filePath, "utf-8")
    return JSON.parse(fileContent) as Visualization
  } catch (error) {
    console.error(`Error reading visualization ${id}:`, error)
    return null
  }
}

// Get a data source by ID
export function getDataSourceById(id: string): DataSource | null {
  ensureDirectories()

  try {
    const files = fs.readdirSync(DATASOURCES_DIR)
    const matchingFile = files.find((file) => file.startsWith(`${id}-`))

    if (!matchingFile) {
      return null
    }

    const filePath = path.join(DATASOURCES_DIR, matchingFile)
    const fileContent = fs.readFileSync(filePath, "utf-8")
    return JSON.parse(fileContent) as DataSource
  } catch (error) {
    console.error(`Error reading data source ${id}:`, error)
    return null
  }
}

// Delete a visualization by ID
export function deleteVisualizationById(id: string): boolean {
  ensureDirectories()

  try {
    const files = fs.readdirSync(VISUALIZATIONS_DIR)
    const matchingFile = files.find((file) => file.startsWith(`${id}-`))

    if (!matchingFile) {
      return false
    }

    const filePath = path.join(VISUALIZATIONS_DIR, matchingFile)
    fs.unlinkSync(filePath)
    return true
  } catch (error) {
    console.error(`Error deleting visualization ${id}:`, error)
    return false
  }
}

// Delete a data source by ID
export function deleteDataSourceById(id: string): boolean {
  ensureDirectories()

  try {
    const files = fs.readdirSync(DATASOURCES_DIR)
    const matchingFile = files.find((file) => file.startsWith(`${id}-`))

    if (!matchingFile) {
      return false
    }

    const filePath = path.join(DATASOURCES_DIR, matchingFile)
    fs.unlinkSync(filePath)
    return true
  } catch (error) {
    console.error(`Error deleting data source ${id}:`, error)
    return false
  }
}


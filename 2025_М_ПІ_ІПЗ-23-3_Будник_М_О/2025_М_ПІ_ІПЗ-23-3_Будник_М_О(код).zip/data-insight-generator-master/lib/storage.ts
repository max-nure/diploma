/**
 * Helper functions for working with localStorage
 */

// Generic function to save data to localStorage
export function saveToLocalStorage<T>(key: string, data: T): void {
  try {
    const serialized = JSON.stringify(data)
    localStorage.setItem(key, serialized)
    console.log(`Saved to localStorage: ${key}`, data)
  } catch (error) {
    console.error(`Error saving to localStorage: ${key}`, error)
  }
}

// Generic function to load data from localStorage
export function loadFromLocalStorage<T>(key: string, defaultValue: T): T {
  try {
    const serialized = localStorage.getItem(key)
    if (serialized === null) {
      return defaultValue
    }
    return JSON.parse(serialized) as T
  } catch (error) {
    console.error(`Error loading from localStorage: ${key}`, error)
    return defaultValue
  }
}


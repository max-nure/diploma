import { type NextRequest, NextResponse } from "next/server"
import {generateObject } from "ai"
import { openai } from "@ai-sdk/openai"
import { anthropic } from "@ai-sdk/anthropic"
import { google } from "@ai-sdk/google"
import { v4 as uuidv4 } from "uuid"
import { parse as csvParse } from "csv-parse/sync"
import { saveVisualization, saveDataSource } from "@/lib/server/storage"
import { deepseek } from '@ai-sdk/deepseek';
import { z } from "zod"


// Helper function to estimate token count (rough approximation)
function estimateTokenCount(text: string): number {
  // A very rough estimate: 1 token ~= 4 characters for English text
  return Math.ceil(text.length / 4)
}

// Function to parse CSV to JSON
function parseCSV(csvData: string): any[] {
  try {
    // Parse CSV with headers
    const records = csvParse(csvData, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      cast: true, // Automatically convert values to native types
    })

    return records
  } catch (error) {
    console.error("Error parsing CSV:", error)
    throw new Error("Failed to parse CSV data")
  }
}


// Comprehensive Zod schema matching the prompt's widget specifications
const ChartWidgetSchema = z.object({
  type: z.literal("chart"),
  chartType: z.enum(["bar", "line", "pie", "area", "scatter"]),
  title: z.string(),
  description: z.string().optional(),
  dataKeys: z.array(z.string()),
  xAxisKey: z.string().optional(),
  colors: z.array(z.string()),
  height: z.number().optional(),
  insights: z.string().optional(),
  dataTransform: z.string()
})

const TableWidgetSchema = z.object({
  type: z.literal("table"),
  title: z.string(),
  description: z.string().optional(),
  columns: z.array(z.object({
    key: z.string(),
    label: z.string()
  })),
  caption: z.string().optional(),
  insights: z.string().optional(),
  dataTransform: z.string()
})

const InsightsWidgetSchema = z.object({
  type: z.literal("insights"),
  title: z.string(),
  description: z.string().optional(),
  insights: z.union([z.array(z.string()), z.string()]),
  insightType: z.enum(["list", "text"])
})

const MetricsWidgetSchema = z.object({
  type: z.literal("metrics"),
  title: z.string(),
  description: z.string().optional(),
  metrics: z.array(z.object({
    label: z.string(),
    value: z.string(),
    change: z.object({
      value: z.number(),
      positive: z.boolean()
    }).optional()
  })),
  dataTransform: z.string()
})

const TitleSchema = z.object({
  title: z.string(),
})

const SummaryWidgetSchema = z.object({
  type: z.literal("summary"),
  title: z.string(),
  content: z.string()
})

const WidgetSchema = z.union([
  ChartWidgetSchema,
  TableWidgetSchema,
  InsightsWidgetSchema,
  MetricsWidgetSchema,
  SummaryWidgetSchema
])

const WidgetsConfigSchema = z.array(WidgetSchema)

// Function to truncate data to fit within token limits
function truncateData(data: any, maxTokens = 50000): { data: any; truncated: boolean } {
  const jsonString = JSON.stringify(data)
  const estimatedTokens = estimateTokenCount(jsonString)

  if (estimatedTokens <= maxTokens) {
    return { data, truncated: false }
  }

  // Data needs to be truncated
  let truncatedData

  if (Array.isArray(data)) {
    // For arrays, limit the number of items
    const truncateRatio = maxTokens / estimatedTokens
    const itemsToKeep = Math.max(10, Math.floor(data.length * truncateRatio))
    truncatedData = data.slice(0, itemsToKeep)
  } else if (typeof data === "object" && data !== null) {
    // For objects, keep a subset of properties
    truncatedData = { ...data }
    const keys = Object.keys(truncatedData)
    const truncateRatio = maxTokens / estimatedTokens
    const keysToKeep = Math.max(5, Math.floor(keys.length * truncateRatio))

    // Keep only a subset of keys
    keys.slice(keysToKeep).forEach((key) => {
      delete truncatedData[key]
    })
  } else {
    // For other types, just return as is
    truncatedData = data
  }

  return { data: truncatedData, truncated: true }
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const model = formData.get("model") as string
    const language = (formData.get("language") as string) || "english"

    // Get data from file upload
    let rawData = ""
    let dataFormat: "json" | "csv" = "json"
    let parsedData: any = null
    const file = formData.get("file") as File

    if (!file || file.size === 0) {
      return NextResponse.json({ error: "Please upload a JSON or CSV file" }, { status: 400 })
    }

    // Check file size before reading (limit to 10MB)
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: "File too large. Please upload a file smaller than 10MB." }, { status: 400 })
    }

    // Get file extension
    const fileName = file.name.toLowerCase()
    if (fileName.endsWith(".json")) {
      dataFormat = "json"
    } else if (fileName.endsWith(".csv")) {
      dataFormat = "csv"
    } else {
      return NextResponse.json({ error: "Only JSON and CSV files are supported" }, { status: 400 })
    }

    // Read and parse the file
    rawData = await file.text()

    try {
      if (dataFormat === "json") {
        parsedData = JSON.parse(rawData)
      } else if (dataFormat === "csv") {
        parsedData = parseCSV(rawData)
      }
    } catch (error) {
      return NextResponse.json(
        {
          error: `Failed to parse ${dataFormat.toUpperCase()} data: ${error instanceof Error ? error.message : "Unknown error"}`,
        },
        { status: 400 },
      )
    }

    if (!parsedData) {
      return NextResponse.json({ error: "No valid data found in the file" }, { status: 400 })
    }

    // Check estimated token count and truncate if necessary
    const MAX_INPUT_TOKENS = 50000 // Conservative limit to leave room for model output
    const { data: truncatedData, truncated } = truncateData(parsedData, MAX_INPUT_TOKENS)

    // Create data source ID
    const dataSourceId = uuidv4()

    // Create data source object
    const dataSource = {
      id: dataSourceId,
      name: file.name,
      data: parsedData,
      originalFormat: dataFormat,
      timestamp: Date.now(),
    }

    // Save the data source to the file system
    saveDataSource(dataSource)

    const languageInstruction =
        language === "ukrainian"
            ? "All text content (titles, descriptions, insights, etc.) should be in Ukrainian language."
            : "All text content should be in English language."

    const titlePrompt = `
You are a data analyst. Based on the following ${dataFormat} data, generate a concise but descriptive title for a data visualization dashboard.
The title should accurately reflect the nature of the data and be between 3-8 words.

DATA SAMPLE:
${JSON.stringify(truncatedData.slice(0, 5), null, 2)}

${truncated ? "Note: The data has been truncated. This is just a sample." : ""}

Return ONLY the title, nothing else.
${languageInstruction}
`


    // Create prompt for the LLM
    const prompt = `
You are a data visualization expert. Analyze the following ${dataFormat} data and create insightful visualizations.

DATA:
${JSON.stringify(truncatedData, null, 2)}

INSTRUCTIONS:
1. Analyze the data to identify patterns, trends, and insights.
2. Create a comprehensive visualization dashboard with multiple components.
3. Return a JSON array of widget configurations that can be rendered by our frontend.
4. Each widget should include a dataTransform function that extracts/processes the specific data needed for that widget.
5. ${languageInstruction}

${truncated ? "Note: The data has been truncated due to size limitations. Analysis is based on a subset of the data." : ""}

Available widget types:

1. Chart Widget:
{
  "type": "chart",
  "chartType": "bar" | "line" | "pie" | "area" | "scatter",
  "title": "Chart Title",
  "description": "Optional description",
  "dataKeys": ["key1", "key2"], // Data keys to visualize
  "xAxisKey": "category", // Key for X-axis
  "colors": ["#color1", "#color2"], // You have to provide colors
  "height": 300, // Optional height
  "insights": "Text explaining insights from this chart",
  "dataTransform": "return data.map(item => ({ ...item, value: item.value * 2 }))" // Transformation function that receives the full dataset and returns the data for this widget.
   Return type should be array of objects.
}

2. Table Widget:
{
  "type": "table",
  "title": "Table Title",
  "description": "Optional description",
  "columns": [
    { "key": "name", "label": "Name" },
    { "key": "value", "label": "Value" }
  ],
  "caption": "Optional table caption",
  "insights": "Text explaining insights from this table",
  "dataTransform": "return data.sort((a, b) => b.value - a.value).slice(0, 10)" // Transformation function that receives the full dataset and returns the data for this widget.
  Round values, add prefixes and suffixes like $,%, this is MUST step - beautify displayed data.
}

3. Insights Widget:
{
  "type": "insights",
  "title": "Key Insights",
  "description": "Optional description",
  "insights": ["Insight 1", "Insight 2", "Insight 3"], // Array of insights or a string
  "insightType": "list" | "text" // Display as list or paragraph
}

4. Metrics Widget:
{
  "type": "metrics",
  "title": "Key Metrics",
  "description": "Optional description",
  "metrics": [
    {
      "label": "Total Sales",
      "value": "$10,000",
      "change": { "value": 5.2, "positive": true } // Optional change indicator
    }
  ],
  "dataTransform": "return { totalSales: data.reduce((sum, item) => sum + item.sales, 0) }" // Transformation function that receives the full dataset and returns data for calculating metrics
}

5. Summary Widget:
{
  "type": "summary",
  "title": "Data Summary",
  "content": "Text summarizing the entire dataset and key findings"
}

IMPORTANT GUIDELINES:
1. For data transformations, provide a valid JavaScript function body that takes the original data as input and returns the transformed data.
2. Make sure all data is properly formatted for the widget type.
3. For charts, ensure the data structure matches what the chart type expects.
4. Provide meaningful insights for each visualization.
5. Return ONLY a valid JSON array of widget configurations.
6. EVERY widget must include a dataTransform function, even if it just returns the original data.
7. Summary widget should always be present and must be first widget in repsponse.

RESPONSE FORMAT:
[
  {widget1},
  {widget2},
  ...
]
`

    // Select the appropriate model based on user choice
    let aiModel
    let modelName

    switch (model) {
      case "claude":
        aiModel = anthropic("claude-3-opus-20240229")
        modelName = "Claude 3 Opus"
        break
      case "gemini":
        aiModel = google("gemini-1.5-pro")
        modelName = "Gemini 1.5 Pro"
        break
      case "deepseek":
        aiModel = deepseek("deepseek-chat")
        modelName = "Deepseek R1"
        break
      case "gpt":
      default:
        aiModel = openai("gpt-4o")
        modelName = "GPT-4o"
        break
    }

    const { object: titleObject } = await generateObject({
      model: aiModel,
      schema: TitleSchema,
      prompt: titlePrompt,
      temperature: 0.7,
      maxTokens: 100,
    })

    // Generate visualization with the AI model
    const { object: widgetsConfig } = await generateObject({
      model: aiModel,
      schema: WidgetsConfigSchema,
      prompt,
      temperature: 0.7,
      maxTokens: 4000,
    })

    // Create visualization object
    const visualization = {
      id: uuidv4(),
      title: titleObject.title as string,
      timestamp: Date.now(),
      widgetsConfig,
      dataSourceId,
      dataType: dataFormat,
      modelUsed: modelName,
      truncated,
    }

    // Save visualization to the file system
    saveVisualization(visualization)

    // Return both the visualization and data source
    return NextResponse.json({
      visualization,
      dataSource,
    })
  } catch (error) {
    console.error("Error processing request:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to process request" },
      { status: 500 },
    )
  }
}


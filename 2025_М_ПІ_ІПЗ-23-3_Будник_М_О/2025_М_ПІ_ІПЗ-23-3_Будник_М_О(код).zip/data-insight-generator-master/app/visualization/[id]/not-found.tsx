import Link from "next/link"
import { Button } from "@/components/ui/button"
import { AlertCircle } from "lucide-react"

export default function VisualizationNotFound() {
  return (
    <div className="container mx-auto px-4 py-16 flex flex-col items-center justify-center">
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-8 max-w-md text-center">
        <AlertCircle className="h-12 w-12 text-amber-700 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-amber-700 mb-2">Visualization Not Found</h1>
        <p className="text-amber-700 mb-6">The visualization you're looking for doesn't exist or has been deleted.</p>
        <Link href="/">
          <Button>Return to Home</Button>
        </Link>
      </div>
    </div>
  )
}


"use client"

import { VisualizationContent } from "@/components/visualization-content"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

interface VisualizationDetailClientProps {
  visualization: Visualization | null
  dataSource: DataSource | null
}

export default function VisualizationDetailClient({ visualization, dataSource }: VisualizationDetailClientProps) {
  return <VisualizationContent visualization={visualization} dataSource={dataSource} />
}


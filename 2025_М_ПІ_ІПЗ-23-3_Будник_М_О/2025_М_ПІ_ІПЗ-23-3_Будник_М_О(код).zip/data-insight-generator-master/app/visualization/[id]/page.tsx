import { Suspense } from "react"
import { notFound } from "next/navigation"
import { fetchVisualizationById, fetchDataSourceById } from "@/app/actions"
import { VisualizationSkeleton } from "@/components/visualization-skeleton"
import { Breadcrumb } from "@/components/breadcrumb"
import { Header } from "@/components/header"
import VisualizationDetailClient from "./visualization-detail-client"

interface VisualizationPageProps {
  params: {
    id: string
  }
}

export default async function VisualizationPage({ params }: VisualizationPageProps) {
  const visualization = await fetchVisualizationById(params.id)

  if (!visualization) {
    notFound()
  }

  const dataSource = await fetchDataSourceById(visualization.dataSourceId)

  return (
      <div className="container mx-auto px-4 py-8">
        <Header />

        <main className="mt-8">
          <Breadcrumb items={[{ label: "Visualizations", href: "/" }, { label: visualization.title }]} />

          <Suspense fallback={<VisualizationSkeleton />}>
            <VisualizationDetailClient visualization={visualization} dataSource={dataSource} />
          </Suspense>
        </main>
      </div>
  )
}


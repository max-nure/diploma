import { Suspense } from "react"
import { fetchVisualizations } from "./actions"
import { Skeleton } from "@/components/ui/skeleton"
import HomepageClient from "./homepage-client"

export default async function Home() {
    // Fetch visualizations on the server
    const visualizations = await fetchVisualizations()

    return (
        <div className="container mx-auto px-4 py-8">
            <Suspense fallback={<HomepageSkeleton />}>
                <HomepageClient initialVisualizations={visualizations} />
            </Suspense>
        </div>
    )
}

function HomepageSkeleton() {
    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pb-6 border-b">
                <Skeleton className="h-10 w-64" />
                <Skeleton className="h-10 w-48" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                    <Skeleton key={i} className="h-[200px] w-full" />
                ))}
            </div>
        </div>
    )
}


import { Suspense } from "react"
import { fetchVisualizations } from "./actions"
import VisualizationDashboard from "@/components/visualization-dashboard"
import { Skeleton } from "@/components/ui/skeleton"

export default async function Home() {
  // Fetch visualizations on the server
  const visualizations = await fetchVisualizations()

  return (
    <div className="container mx-auto px-4 py-8">
      <Suspense fallback={<DashboardSkeleton />}>
        <VisualizationDashboard initialVisualizations={visualizations} />
      </Suspense>
    </div>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 pb-6 border-b">
        <Skeleton className="h-10 w-64" />
        <div className="flex items-center gap-2">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
      </div>

      <div className="h-[500px] w-full border-2 border-dashed rounded-lg flex items-center justify-center">
        <Skeleton className="h-8 w-64" />
      </div>
    </div>
  )
}


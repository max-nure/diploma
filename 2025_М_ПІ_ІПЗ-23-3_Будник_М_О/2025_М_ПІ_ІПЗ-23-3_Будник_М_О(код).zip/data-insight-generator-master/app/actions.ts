"use server"

import { revalidatePath } from "next/cache"
import {
  getAllVisualizations,
  getVisualizationById,
  getDataSourceById,
  deleteVisualizationById,
  deleteDataSourceById,
} from "@/lib/server/storage"
import type { Visualization } from "@/types/visualization"
import type { DataSource } from "@/types/data-source"

// Get all visualizations
export async function fetchVisualizations(): Promise<Visualization[]> {
  return getAllVisualizations()
}

// Get a visualization by ID
export async function fetchVisualizationById(id: string): Promise<Visualization | null> {
  return getVisualizationById(id)
}

// Get a data source by ID
export async function fetchDataSourceById(id: string): Promise<DataSource | null> {
  return getDataSourceById(id)
}

// Delete a visualization
export async function deleteVisualization(id: string): Promise<boolean> {
  const result = deleteVisualizationById(id)
  revalidatePath("/")
  return result
}

// Delete a data source
export async function deleteDataSource(id: string): Promise<boolean> {
  const result = deleteDataSourceById(id)
  revalidatePath("/")
  return result
}


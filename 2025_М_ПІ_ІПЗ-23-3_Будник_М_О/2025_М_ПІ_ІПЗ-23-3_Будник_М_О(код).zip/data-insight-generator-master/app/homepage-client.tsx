"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { VisualizationCard } from "@/components/visualization-card"
import { Button } from "@/components/ui/button"
import { PlusCircle } from "lucide-react"
import { NewVisualization } from "@/components/new-visualization"
import type { Visualization } from "@/types/visualization"

interface HomepageClientProps {
  initialVisualizations: Visualization[]
}

export default function HomepageClient({ initialVisualizations }: HomepageClientProps) {
  const [visualizations] = useState<Visualization[]>(initialVisualizations)

  return (
      <>
        <Header />

        <main className="mt-8">
          {visualizations.length > 0 ? (
              <>
                <h2 className="text-2xl font-bold mb-6">Your Visualizations</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {visualizations.map((visualization) => (
                      <VisualizationCard key={visualization.id} visualization={visualization} />
                  ))}
                </div>
              </>
          ) : (
              <div className="text-center p-12 border-2 border-dashed rounded-lg">
                <h3 className="text-xl font-medium mb-2">No visualizations yet</h3>
                <p className="text-muted-foreground mb-6">Create your first visualization to get started.</p>
                <NewVisualization
                    trigger={
                      <Button>
                        <PlusCircle className="h-4 w-4 mr-2" />
                        Create New Visualization
                      </Button>
                    }
                />
              </div>
          )}
        </main>
      </>
  )
}

